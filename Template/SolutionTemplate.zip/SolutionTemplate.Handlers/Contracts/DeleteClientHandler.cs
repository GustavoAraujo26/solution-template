﻿using ArchitectureTools.Responses;
using AutoMapper;
using FluentValidation;
using $ext_safeprojectname$.Domain.Handlers;
using $ext_safeprojectname$.Domain.Repositories;
using $ext_safeprojectname$.Domain.Requests;
using $ext_safeprojectname$.Domain.Responses;
using $ext_safeprojectname$.Shared.Extensions;

namespace $safeprojectname$.Contracts
{
    public sealed class DeleteClientHandler : IDeleteClientHandler
    {
        private readonly IMapper mapper;
        private readonly IClientRepository repository;
        private readonly IValidator<DeleteClientRequest> validator;

        public DeleteClientHandler(IMapper mapper, IClientRepository repository, IValidator<DeleteClientRequest> validator)
        {
            this.mapper = mapper;
            this.repository = repository;
            this.validator = validator;
        }

        public async Task<ActionResponse<ClientResponse>> Handle(DeleteClientRequest request, 
            CancellationToken cancellationToken)
        {
            var validationResponse = validator.Validate(request);
            if (!validationResponse.IsValid)
                return validationResponse.ConvertToResponse<ClientResponse>();

            var entity = await repository.Get(request.Id);
            if (entity is null)
                return ActionResponse<ClientResponse>.NotFound("Cliente nao encontrado.");

            await repository.Delete(request.Id);

            return ActionResponse<ClientResponse>.Ok();
        }
    }
}
