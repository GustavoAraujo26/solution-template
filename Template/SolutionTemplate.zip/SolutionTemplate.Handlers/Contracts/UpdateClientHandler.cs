﻿using ArchitectureTools.Responses;
using AutoMapper;
using FluentValidation;
using $ext_safeprojectname$.Domain.Entities;
using $ext_safeprojectname$.Domain.Handlers;
using $ext_safeprojectname$.Domain.Repositories;
using $ext_safeprojectname$.Domain.Requests;
using $ext_safeprojectname$.Domain.Responses;
using $ext_safeprojectname$.Shared.Extensions;

namespace $safeprojectname$.Contracts
{
    public class UpdateClientHandler : IUpdateClientHandler
    {
        private readonly IMapper mapper;
        private readonly IClientRepository repository;
        private readonly IValidator<UpdateClientRequest> validator;

        public UpdateClientHandler(IMapper mapper, IClientRepository repository, 
            IValidator<UpdateClientRequest> validator)
        {
            this.mapper = mapper;
            this.repository = repository;
            this.validator = validator;
        }

        public async Task<ActionResponse<ClientResponse>> Handle(UpdateClientRequest request, 
            CancellationToken cancellationToken)
        {
            var validationResponse = validator.Validate(request);
            if (!validationResponse.IsValid)
                return validationResponse.ConvertToResponse<ClientResponse>();

            var currentClient = await repository.Get(request.Id);
            if (currentClient is null)
                return ActionResponse<ClientResponse>.NotFound("Cliente nao encontrado.");

            var entity = mapper.Map<Client>(request);

            await repository.Save(entity);

            return ActionResponse<ClientResponse>.Ok();
        }
    }
}
