﻿using ArchitectureTools.Responses;
using AutoMapper;
using FluentValidation;
using $ext_safeprojectname$.Domain.Entities;
using $ext_safeprojectname$.Domain.Handlers;
using $ext_safeprojectname$.Domain.Repositories;
using $ext_safeprojectname$.Domain.Requests;
using $ext_safeprojectname$.Domain.Responses;
using $ext_safeprojectname$.Shared.Extensions;

namespace $safeprojectname$.Contracts
{
    public sealed class CreateClientHandler : ICreateClientHandler
    {
        private readonly IMapper mapper;
        private readonly IValidator<CreateClientRequest> validator;
        private readonly IClientRepository repository;

        public CreateClientHandler(IMapper mapper, IValidator<CreateClientRequest> validator, 
            IClientRepository repository)
        {
            this.mapper = mapper;
            this.validator = validator;
            this.repository = repository;
        }

        public async Task<ActionResponse<ClientResponse>> Handle(CreateClientRequest request, 
            CancellationToken cancellationToken)
        {
            var validationResponse = validator.Validate(request);
            if (!validationResponse.IsValid)
                return validationResponse.ConvertToResponse<ClientResponse>();

            var entity = mapper.Map<Client>(request);

            await repository.Save(entity);

            return ActionResponse<ClientResponse>.Ok();
        }
    }
}
