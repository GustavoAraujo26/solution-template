﻿using ArchitectureTools.Pagination;
using $ext_safeprojectname$.Domain.Entities;
using $ext_safeprojectname$.Domain.Repositories;
using $ext_safeprojectname$.Domain.Requests;
using $ext_safeprojectname$.Domain.Responses;

namespace $safeprojectname$.Contracts
{
    internal class ClientRepository : IClientRepository
    {
        public Task Delete(Guid id)
        {
            throw new NotImplementedException();
        }

        public Task<ClientResponse> Get(Guid id)
        {
            throw new NotImplementedException();
        }

        public Task<ClientResponse> Get(string name)
        {
            throw new NotImplementedException();
        }

        public Task<PaginationResponse<ClientResponse>> List(ListClientsRequest request)
        {
            throw new NotImplementedException();
        }

        public Task Save(Client client)
        {
            throw new NotImplementedException();
        }
    }
}
