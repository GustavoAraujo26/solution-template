﻿using Moq;
using $ext_safeprojectname$.Domain.Entities;
using $ext_safeprojectname$.Domain.Repositories;
using $safeprojectname$.FakeData.Responses;

namespace $safeprojectname$.Mocks
{
    internal static class ClientRepositoryMock
    {
        public static IMock<IClientRepository> Build(Guid? id = null)
        {
            var mock = new Mock<IClientRepository>();

            mock.Setup(x => x.Get(It.IsAny<Guid>()))
                .ReturnsAsync(ClientResponseFakeData.Build(id));

            mock.Setup(x => x.Save(It.IsAny<Client>()));

            mock.Setup(x => x.Delete(It.IsAny<Guid>()));

            return mock;
        }

        public static IMock<IClientRepository> BuildGetNotFound()
        {
            var mock = new Mock<IClientRepository>();

            mock.Setup(x => x.Get(It.IsAny<Guid>()));

            return mock;
        }
    }
}
