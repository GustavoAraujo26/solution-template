﻿using AutoBogus;
using $ext_safeprojectname$.Domain.Requests;

namespace $safeprojectname$.FakeData.Requests
{
    internal static class DeleteClientRequestFakeData
    {
        public static DeleteClientRequest Build()
        {
            var faker = new AutoFaker<DeleteClientRequest>();

            faker.RuleFor(x => x.Id, y => Guid.NewGuid());

            return faker.Generate();
        }
    }
}
