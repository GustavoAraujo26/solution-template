﻿using AutoBogus;
using $ext_safeprojectname$.Domain.Requests;

namespace $safeprojectname$.FakeData.Requests
{
    internal static class CreateClientRequestFakeData
    {
        public static CreateClientRequest Build()
        {
            var faker = new AutoFaker<CreateClientRequest>();

            faker.RuleFor(x => x.Name, y => y.Person.FullName);

            return faker.Generate();
        }
    }
}
