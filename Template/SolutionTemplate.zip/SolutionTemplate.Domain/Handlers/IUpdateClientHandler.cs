﻿using ArchitectureTools.Responses;
using MediatR;
using $safeprojectname$.Requests;
using $safeprojectname$.Responses;

namespace $safeprojectname$.Handlers
{
    /// <summary>
    /// Interface do manipulador de atualização de clientes
    /// </summary>
    public interface IUpdateClientHandler : IRequestHandler<UpdateClientRequest, ActionResponse<ClientResponse>>
    {
    }
}
