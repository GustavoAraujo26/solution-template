﻿using ArchitectureTools.Responses;
using MediatR;
using $safeprojectname$.Requests;
using $safeprojectname$.Responses;

namespace $safeprojectname$.Handlers
{
    /// <summary>
    /// Interface do manipulador de criação de clientes
    /// </summary>
    public interface ICreateClientHandler : IRequestHandler<CreateClientRequest, ActionResponse<ClientResponse>>
    {
    }
}
