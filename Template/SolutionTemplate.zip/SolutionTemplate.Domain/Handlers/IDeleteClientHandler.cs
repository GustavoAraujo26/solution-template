﻿using ArchitectureTools.Responses;
using MediatR;
using $safeprojectname$.Requests;
using $safeprojectname$.Responses;

namespace $safeprojectname$.Handlers
{
    /// <summary>
    /// Interface do manipulador de deleção de clientes
    /// </summary>
    public interface IDeleteClientHandler : IRequestHandler<DeleteClientRequest, ActionResponse<ClientResponse>>
    {
    }
}
