﻿using AutoMapper;
using $ext_safeprojectname$.Domain.Entities;
using $ext_safeprojectname$.Domain.Requests;

namespace $safeprojectname$.Entities
{
    internal class UpdateClientTypeConverter : ITypeConverter<UpdateClientRequest, Client>
    {
        public Client Convert(UpdateClientRequest source, Client destination, ResolutionContext context)
        {
            return new Client(source.Id, source.Name, source.Status);
        }
    }
}
