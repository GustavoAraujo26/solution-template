﻿using AutoMapper;
using $ext_safeprojectname$.Domain.Entities;
using $ext_safeprojectname$.Domain.Enums;
using $ext_safeprojectname$.Domain.Requests;

namespace $safeprojectname$.Entities
{
    internal class CreateClientTypeConverter : ITypeConverter<CreateClientRequest, Client>
    {
        public Client Convert(CreateClientRequest source, Client destination, ResolutionContext context)
        {
            return new Client(Guid.NewGuid(), source.Name, StatusType.Enabled);
        }
    }
}
