﻿using AutoMapper;
using $ext_safeprojectname$.Domain.Entities;
using $ext_safeprojectname$.Domain.Requests;
using $safeprojectname$.Entities;

namespace $safeprojectname$.Profiles
{
    public class ClientProfile : Profile
    {
        public ClientProfile()
        {
            CreateMap<CreateClientRequest, Client>()
                .ConvertUsing<CreateClientTypeConverter>();

            CreateMap<UpdateClientRequest, Client>()
                .ConvertUsing<UpdateClientTypeConverter>();
        }
    }
}
