﻿using FluentValidation;
using $ext_safeprojectname$.Domain.Requests;

namespace $safeprojectname$.Contracts
{
    public class CreateClientValidator : AbstractValidator<CreateClientRequest>
    {
        public CreateClientValidator()
        {
            RuleFor(x => x.Name)
                .Cascade(CascadeMode.Continue)
                .NotNull()
                .NotEmpty()
                .MaximumLength(100);
        }
    }
}
