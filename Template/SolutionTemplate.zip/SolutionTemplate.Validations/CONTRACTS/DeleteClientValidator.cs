﻿using FluentValidation;
using $ext_safeprojectname$.Domain.Requests;

namespace $safeprojectname$.Contracts
{
    public class DeleteClientValidator : AbstractValidator<DeleteClientRequest>
    {
        public DeleteClientValidator()
        {
            RuleFor(x => x.Id).NotEqual(Guid.Empty);
        }
    }
}
